% Semisolid MT/CEST MRF pipeline demonstration
% Kai Herz and Or Perlman 2021
% kai.herz@tuebingen.mpg.de; operlman@mgh.harvard.edu

%% Step 1 - choose imaging subject
% 'phantom' / 'mouse'
subject = 'phantom';
disp(['Selected imaging subject: ', subject]);

%% Step 2 - Generate a dictionary

% Installing packages (will be skipped automatically if already installed)
install_pulseq_cest_mrf

% Generate dictionary
t1=clock;
switch subject
    case 'phantom'
        generate_dict_phantom
    case 'mouse'
        generate_dict_mouse
    otherwise
        disp('Subject should be: phantom / mouse')
end

t2=clock;
disp(['Dictionary generation took ',num2str(etime(t2,t1)/60), ' min'])
disp('Three files were created and saved:')
disp('1. Acquisition protocol (acq_protocol.seq)')
disp('2. Simulated biological scenario (scenario.yaml)')
disp('3. Dictionary (dict.mat)')

% Clearing irrelevant variables
clearvars -except subject

%% Step 3 - Dot product matching and plotting results

% Loading the acquired data
acquired_data = zeros(30, 64, 64);
for ind = 1:30
    if ind<10
        acquired_data(ind, :, :) = double(dicomread(['../data/',subject, '/MRIm0', num2str(ind), '.dcm']));
    else
        acquired_data(ind, :, :) = double(dicomread(['../data/',subject, '/MRIm', num2str(ind), '.dcm']));
        
    end
end

% Load the generated dictionary
load dict.mat dict

t1=clock;
quant_maps = dot_prod_matching(dict, acquired_data);
t2=clock;
disp(['Dot product matching took ',num2str(etime(t2,t1)), ' sec'])
save('quant_maps.mat', 'quant_maps');
disp('Quantitative semisolid MT/CEST maps are now be available as quant_maps.mat')

% Plotting dot-product matched maps

% Setting graphic parameters
set(0, 'DefaultAxesLineWidth', 1.2, 'DefaultAxesFontSize', 12, ...
    'DefaultAxesFontWeight', 'bold', 'DefaultAxesFontname','Times New Roman',...
    'DefaultLineLineWidth', .2, 'DefaultLineMarkerSize', 8);
set(0,'defaultfigurecolor',[1 1 1])

figure

switch subject
    
    case 'phantom'
        ax1 = subplot(121);
        imagesc(quant_maps.fs.*110e3/3, [0, 120]);
        colormap(ax1,parula)
        colorbar
        axis off
        title('[L-arg] (mM)')
        
        ax2 = subplot(122);
        imagesc(quant_maps.ksw, [0 500]);
        colormap(ax2, hot)
        colorbar
        axis off
        title('k_{sw} (Hz)')
        
    case 'mouse'
        ax1 = subplot(121);
        imagesc(quant_maps.fs.*100, [0, 30]);
        colormap(ax1,parula)
        colorbar
        axis off
        title('f_{ss} (%)')
        
        ax2 = subplot(122);
        imagesc(quant_maps.ksw, [0 50]);
        colormap(ax2, hot)
        colorbar
        axis off
        title('k_{ssw} (Hz)')
        
    otherwise
        disp('Subject should be: phantom / mouse')
end