For information about the C++ source code, you can generate an automatic doxygen documentation from the provided [Doxyfile](Doxyfile). The output will be written to pulseq-cest-sim/doc and you can view it by opening the generated index.html file.

Check out the doxygen [documentation](https://www.doxygen.nl/manual/starting.html#step2) for more info.
